# projet1_distributed_computing

How to Compile: sh flood.sh

How to Run: once it is compiled, run FloodMax by './FloodMax' 

In addition to injecting input file to the code, you can manually type in the input filename(complete name including location if it is not in the working directory)

Don't forget to have fun y'all